//
//  AddViewController.swift
//  Contacts
//
//  Created by AMBIN03095 on 03/02/22.
//

import UIKit
protocol newContact {
    func newContactAdd(on data: Numbers)
}

class AddViewController: UIViewController, UITableViewDelegate {
    var delegate: newContact!
    @IBOutlet weak var cName: UITextField!
    @IBOutlet weak var pNum: UITextField!
    //var dataArray : [Numbers] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func addNum(_ sender: Any) {
        print("sucess")
        if let cName = self.cName?.text, let pNum = self.pNum?.text {
            if cName.isEmpty || pNum.isEmpty {
                print("done")
                // let anjan = Numbers(name:cName,image: "s", number:pNum)
                //   dataArray.insert(anjan,at:dataArray.count+1)
                
                //performSegue(withIdentifier: "navigateToHome", sender: anjan)
                
            } else {
                let anjan = Numbers(name:cName,image: "img.jpeg", number:pNum)
                print(anjan)
                delegate?.newContactAdd(on: anjan )
                navigationController?.popViewController(animated: true)
                //performSegue(withIdentifier: "navigateToHome", sender: self )
                //  self.labelerror.text = "login sucessfull"
                
            }
            
        }
        
    }
    @IBAction func cancelNum(_ sender: Any) {
        print("Cancel")
        //    performSegue(withIdentifier: "navigateToHome", sender: anjan)
    }
    /*  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     if let destinationController = segue.destination as? HomeViewController, let anjan = sender as? Numbers {
     destinationController.anjan = anjan
     }
     }*/
    
    
}

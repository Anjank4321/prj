//
//  DetailViewController.swift
//  Contacts
//
//  Created by AMBIN03095 on 02/02/22.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var callLog: UILabel!
    @IBOutlet weak var Message: UILabel!
    var person: Numbers? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        if let person = self.person {
            self.imageView.image = UIImage(named: person.image)
            
        }
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

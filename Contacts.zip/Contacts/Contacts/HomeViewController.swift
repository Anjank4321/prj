//
//  HomeViewController.swift
//  Contacts
//
//  Created by AMBIN03095 on 02/02/22.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    var anjan: Numbers?
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    var dataArray : [Numbers] = []
    //var data = ["Virat","Sai","Anil","Monica","Anjan","Anvesh"]
    var filerData:[String]!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        searchBar.delegate = self
        dataArray = self.getContactName()
        // if let anjan = self.anjan{
        // dataArray.insert(anjan, at: dataArray.count+1)
        // tableView.reloadData()
        // }
        title = "Contacts"
        // Do any additional setup after loading the view.
    }
    
    @IBAction func add(_ sender: Any) {
        
        // self.performSegue(withIdentifier:"navigateToHome" , sender: self)
        if let nextVC = UIStoryboard(name: "Main",bundle: nil).instantiateViewController(withIdentifier: "AddViewController") as? AddViewController {
            nextVC.delegate = self
            navigationController?.pushViewController(nextVC, animated: true)
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(dataArray.count)
        return self.dataArray.count
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? details
        let person = self.dataArray[indexPath.row]
        cell?.contactName?.text = person.name
        //  cell?.contactName?.text = filerData[indexPath.row]
        cell?.contactImage?.image = UIImage(named:person.image)
        cell?.contactNumber?.text = person.number
        
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let person = self.dataArray[indexPath.row]
        self.performSegue(withIdentifier: "navigateTodetail", sender: person)
        
    }
    
    func getContactName() -> [Numbers] {
        return [Numbers(name: "virat", image: "virat.jpeg",number: "885739"),Numbers(name: "Anil", image: "anil.jpeg" ,number: "885739"),
                Numbers(name: "Sai", image: "sai.jpeg" ,number: "885739"),Numbers(name: "Monica", image: "img.jpeg" ,number: "885739")]
    }
    /* func searchBar(_searchBar :UISearchBar, textDidChange searchText: String) {
     filerData = []
     if searchText == "" {
     filerData = String(dataArray.name)
     } else {
     for entity in dataArray {
     if entity.lowercased().contains(searchText.lowercased()) {
     filerData.append(entity)
     }
     
     }
     }
     self.tableView.reloadData()
     }*/
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? DetailViewController, let person = sender as? Numbers {
            destination.person = person
        }
    }
    
}
extension HomeViewController: newContact {
    func newContactAdd(on data: Numbers) {
        dataArray.append(data)
        tableView.reloadData()
        
    }
    
    
}

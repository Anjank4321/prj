//
//  numbers.swift
//  Contacts
//
//  Created by AMBIN03095 on 02/02/22.
//

import Foundation
import UIKit
struct Numbers {
    let name :String
    let image :String
    let number :String
}

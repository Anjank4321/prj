//
//  SecondViewController.swift
//  DelegationDemo1
//
//  Created by Ashraf, Ali on 31/10/21.
//

import UIKit

protocol PerformActionOnDataProtocol: AnyObject {
    func performAction(on someData: String)
}

class SecondViewController: UIViewController {
    @IBOutlet weak var entryTextField: UITextField!
    weak var delegate: PerformActionOnDataProtocol!
    
    override func viewDidLoad() {
        super.viewDidLoad()
         title = "Second View Controller"
    }
    
    @IBAction func submitTapped() {
        delegate.performAction(on: entryTextField.text ?? "")
        navigationController?.popViewController(animated: true)
    }
}

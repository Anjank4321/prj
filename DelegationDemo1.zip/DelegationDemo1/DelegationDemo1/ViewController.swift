//
//  ViewController.swift
//  DelegationDemo1
//
//  Created by Ashraf, Ali on 31/10/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var entryLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "First View Controller"
    }

    @IBAction func gotoNextScreen() {
        if let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController {
            nextVC.delegate = self
            navigationController?.pushViewController(nextVC, animated: true)
        }
    }
}


extension ViewController: PerformActionOnDataProtocol {
    func performAction(on someData: String) {
        // do any action on someData
        entryLabel.text = someData
    }
}

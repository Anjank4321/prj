//
//  ViewController.swift
//  MVVMDemo1
//
//  Created by Ashraf, Ali on 09/11/21.
//

import UIKit

struct Student {
    var name: String
    var id: String
    var telugu: Int
    var hindi: Int
    var english: Int
}

class ViewController: UIViewController {
    @IBOutlet weak var studentsTableView: UITableView!
    
    var tableData: [Student]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Students"
        studentsTableView.register(UINib(nibName: "StudentCell", bundle: nil), forCellReuseIdentifier: "StudentCell")
        prepareModel()
        studentsTableView.reloadData()
    }

    func prepareModel() {
        if tableData == nil {
            tableData = [Student]()
        } else {
            tableData?.removeAll()
        }
        
        tableData?.append(Student(name: "gopi", id: "101", telugu: 60, hindi: 65, english: 72))
        tableData?.append(Student(name: "kiran", id: "101", telugu: 73, hindi: 82, english: 64))
        tableData?.append(Student(name: "sathya", id: "101", telugu: 82, hindi: 79, english: 70))
    }
}

extension ViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = tableData?.count ?? 0
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "StudentCell", for: indexPath) as? StudentCell else {
            return UITableViewCell()
        }
        
        let student = tableData?[indexPath.row]
        cell.configure(student)
        return cell
    }
}

//
//  Student.swift
//  MVVMDemo2
//
//  Created by Ashraf, Ali on 09/11/21.
//

import Foundation

struct Student {
    var name: String
    var id: String
    var telugu: Int
    var hindi: Int
    var english: Int
}

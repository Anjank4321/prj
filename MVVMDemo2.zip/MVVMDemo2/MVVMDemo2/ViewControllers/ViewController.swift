//
//  ViewController.swift
//  MVVMDemo2
//
//  Created by Ashraf, Ali on 09/11/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var studentsTableView: UITableView!
    var viewModel = StudentsViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = viewModel.getTitle()
        studentsTableView.register(UINib(nibName: "StudentCell", bundle: nil), forCellReuseIdentifier: "StudentCell")
        viewModel.prepareModel()
        studentsTableView.reloadData()
    }
}

extension ViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.getNumberOfSections()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "StudentCell", for: indexPath) as? StudentCell else {
            return UITableViewCell()
        }
        
        let student = viewModel.getStudent(at: indexPath.row)
        cell.configure(student)
        return cell
    }
}

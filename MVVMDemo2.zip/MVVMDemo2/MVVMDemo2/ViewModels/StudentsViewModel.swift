//
//  StudentsViewModel.swift
//  MVVMDemo2
//
//  Created by Ashraf, Ali on 09/11/21.
//

import Foundation

class StudentsViewModel {
    var tableData: [Student]?
    
    func getTitle() -> String {
        return "Students"
    }
    
    func getNumberOfSections() -> Int {
        return 1
    }
    
    func getNumberOfRows() -> Int {
        let count = tableData?.count ?? 0
        return count
    }
    
    func prepareModel() {
        if tableData == nil {
            tableData = [Student]()
        } else {
            tableData?.removeAll()
        }
        
        tableData?.append(Student(name: "gopi", id: "101", telugu: 60, hindi: 65, english: 72))
        tableData?.append(Student(name: "kiran", id: "101", telugu: 73, hindi: 82, english: 64))
        tableData?.append(Student(name: "sathya", id: "101", telugu: 82, hindi: 79, english: 70))
    }
    
    func getStudent(at index: Int) -> Student? {
        return tableData?[index]
    }
}

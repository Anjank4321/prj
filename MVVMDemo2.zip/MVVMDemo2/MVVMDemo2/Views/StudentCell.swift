//
//  StudentCell.swift
//  MVVMDemo1
//
//  Created by Ashraf, Ali on 09/11/21.
//

import UIKit

class StudentCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var totalMarksLabel: UILabel!
    
    func configure(_ studentInfo: Student?) {
        guard let student = studentInfo else {
            return
        }
        nameLabel.text = student.name
        totalMarksLabel.text = String(student.telugu + student.hindi + student.english)
    }
}

//
//  HomeViewController.swift
//  mounika task
//
//  Created by AMBIN03095 on 06/07/22.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var empname: UILabel!
    @IBOutlet weak var empid: UILabel!
    @IBOutlet weak var empcontact: UILabel!
    @IBOutlet weak var empadd: UILabel!
    @IBOutlet weak var empage: UILabel!
    var selectName : Data!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.empname.text = "\(selectName.firstName)" + " " + "\(selectName.lastName)"
            self.empage.text = selectName.age
            self.empadd.text = selectName.address
            self.empcontact.text = selectName.contactDetails
        self.empid.text = selectName.employeID
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

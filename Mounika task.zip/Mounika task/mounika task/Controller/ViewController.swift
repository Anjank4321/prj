//
//  ViewController.swift
//  mounika task
//
//  Created by AMBIN03095 on 06/07/22.
//
import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate {
    @IBOutlet weak var searchbar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    var items: [Data] = []
    var filteredData : [Data] = []
    var Array : [String]!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getItems()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.searchbar.delegate = self
        searchbar.autocorrectionType = .no
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectName =  self.items[indexPath.row]
        self.performSegue(withIdentifier: "navigateToHome", sender: selectName)
    }
    func  getItems() {
        let defaultSession = URLSession(configuration: URLSessionConfiguration.default)
        var dataTask: URLSessionTask?
        let url = URL(string:"https://demo1792672.mockable.io/parashuram036")!
        let urlRequest = URLRequest(url: url)
        dataTask = defaultSession.dataTask(with: urlRequest, completionHandler: { data, response, error in
           if error != nil{
               print(error?.localizedDescription as Any)
               
           }
            if let tempData = data {
                if let welcome = try? JSONDecoder().decode(Employees.self,from:tempData) {
                    DispatchQueue.main.async {
                        self.items = welcome.employees
                        let sortedPlayers = self.items.sorted { $0.firstName.compare($1.firstName) == .orderedAscending }
                        print(sortedPlayers)
                        self.items = sortedPlayers
                        
                        self.filteredData = sortedPlayers
                        self.tableView.reloadData()
                        
                    }
            }
            
        }
            
        })
        dataTask?.resume()

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filteredData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableViewCell")
        let item = self.filteredData[indexPath.row]
        cell?.textLabel?.text = item.firstName
        cell?.detailTextLabel?.text = item.lastName
        return cell!
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
       /* if searchText != "" {
            filteredData = items.filter({ item in
                return item.firstName.lowercased().hasPrefix(searchText.lowercased())
            })
            tableView.reloadData()}*/
        if searchText != "" {
            filteredData = items.filter({$0.firstName.lowercased().contains(searchText.lowercased())})
            tableView.reloadData()
        }
        else{
            print("please enter employee name")
            filteredData = items
            tableView.reloadData()
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let destination = segue.destination as? HomeViewController, let selectName = sender as? Data {
                destination.selectName = selectName
            }
        }
}



//
//  user.swift
//  mounika task
//
//  Created by AMBIN03095 on 08/07/22.
//

import Foundation
struct EmployeeManager {
    let 
}

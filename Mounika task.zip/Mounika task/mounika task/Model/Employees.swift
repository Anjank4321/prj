//
//  Employees.swift
//  mounika task
//
//  Created by AMBIN03095 on 07/07/22.
//

import Foundation
struct Employees: Codable {
    let employees: [Data]
}
struct Data: Codable {
    let firstName: String
    let lastName: String
    let age:String
    let employeID:String
    let contactDetails:String
    let address:String
}

//
//  DetailViewController.swift
//  Restuarant
//
//  Created by AMBIN03095 on 29/01/22.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var ViewLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    var varity: Items? = nil
    override func viewDidLoad() {
        
        super.viewDidLoad()
        title = varity?.name
        if let varity = self.varity {
            self.imageView.image = UIImage(named: varity.image)
            self.ViewLabel.text = varity.describe
            self.rating.text = "rating  \(String(varity.rating))"
        }
         
    }
    

    
}

//
//  items.swift
//  Restuarant
//
//  Created by AMBIN03095 on 25/01/22.
//

import Foundation
import UIKit
struct Items {
    let name : String
    let image : String
    let rating : Float
    let describe : String
}


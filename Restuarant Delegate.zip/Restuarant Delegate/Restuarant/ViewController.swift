//
//  ViewController.swift
//  Restuarant
//
//  Created by AMBIN03095 on 25/01/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var labelerror: UILabel!
    var varity: Items? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        if let varity = self.varity {
        
        labelerror.text = varity.name
        // Do any additional setup after loading the view.
    }
        
    }


    @IBAction func VegDishes(_ sender: Any) {
        if let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController{
            nextVC.menuType = "VegDishes"
           // nextVC.delegate = self
            navigationController?.pushViewController(nextVC, animated: true)
        }
    }
    
    //@IBAction func NonVegDishes(_ sender: Any) {
 //   }
    
    @IBAction func nonvegDishes(_ sender: Any) {
        if let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController{
            nextVC.menuType = "NonVegDishes"
           // nextVC.delegate = self
            navigationController?.pushViewController(nextVC, animated: true)
        }
    }
}
/*extension ViewController:PerformActionOnData {
   func performAction(on SomeData:String) {

       labelerror.text = "\(SomeData) This is the last item you tapped!!😋😋😋"



    }
}*/

//
//  vegMenu.swift
//  Restuarant
//
//  Created by AMBIN03095 on 25/01/22.
//

import UIKit

class vegMenu: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var imgveg: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

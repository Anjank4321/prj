//
//  HomeViewController.swift
//  Restuarant
//
//  Created by AMBIN03095 on 25/01/22.
//

import UIKit

class HomeViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var TableView: UITableView!
    var dataarray : [Items] = []
    var menuType: String? = nil
    override func viewDidLoad() {
        
        super.viewDidLoad()
        if (menuType == "VegDishes") {
            dataarray = self.getItemsdetails()
            title = "veg Menu"
        } else {
            dataarray = self.getItemnonVegdetails()
            title = " nonvegMenu"
        }
        self.TableView.dataSource = self
        self.TableView.delegate = self
      //  dataarray = self.getItemsdetails()
        
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataarray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? vegMenu
        let varity = self.dataarray[indexPath.row]
        //cell?.label.text = String(varity.rating)
        cell?.label.text = varity.name
        cell?.imgveg.image = UIImage(named: varity.image)
        
        //cell?.label.text = vijaya.name
        return cell!
       
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let varity = self.dataarray[indexPath.row]
        self.performSegue(withIdentifier: "DetailViewController", sender: varity)
        
        }
    func getItemsdetails() -> [Items] {
        return [Items(name: "curry", image: "curry.jpeg",rating: 4.9,describe:"it is the Combination of Kaju and Butter"),
                Items(name: "Biriyani", image: "biriyani.jpeg",rating: 5,describe:"it is the Paneer and kaju"),
                Items(name: "Butturnaan", image: "roti.jpeg",rating: 4.8,describe:"it is the Butter and maidha"),
                Items(name: "Burger", image: "burger.jpeg",rating: 4.7,describe:"it is the fdgnaejr")]
        
    }
    
    
    func getItemnonVegdetails() ->[Items] {
        return [Items(name: "chicken", image: "curry.jpeg", rating: 3.55,describe:" Chicken plus cheese "),
                Items(name: "dhumBiriyani", image: "biriyani.jpeg",rating: 3.14197,describe:"it is the cosadf"),
                Items(name: "Butturnaan", image: "roti.jpeg",rating: 4.136,describe:"it is the cosadf"),
                Items(name: "Burger", image: "burger.jpeg",rating: 5,describe:"it is the cosadf")]
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? DetailViewController, let varity = sender as? Items {
            destination.varity = varity 
        }
    }

}

//
//  AppData.swift
//  SingletonDemo1
//
//  Created by Ashraf, Ali on 01/11/21.
//

import Foundation
class AppData {
    static let shared = AppData()
    var entryLabelValue: String?
    
    private init() {
        // intentionally left blank
    }
}

//
//  SecondViewController.swift
//  SingletonDemo1
//
//  Created by Ashraf, Ali on 01/11/21.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var entryTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Second View Controller"
    }
    
    @IBAction func submitTapped() {
        AppData.shared.entryLabelValue = entryTextField.text
        navigationController?.popViewController(animated: true)
    }
}

//
//  ViewController.swift
//  SingletonDemo1
//
//  Created by Ashraf, Ali on 01/11/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var entryLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "First View Controller"
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if let enteredValue = AppData.shared.entryLabelValue {
            entryLabel.text = enteredValue
        }
    }
    
    @IBAction func gotoNextScreen() {
        if let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController {
            navigationController?.pushViewController(nextVC, animated: true)
        }
    }
}


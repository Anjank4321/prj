//
//  ViewController.swift
//  attensions using Wkreview
//
//  Created by AMBIN03095 on 17/03/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        let label = Demolabel()
        let label = UILabel()
        label.text = "Sample text"
        label.sizeToFit()
        label.setContent()
        label.frame = CGRect(x:100, y: 100,width:200,height:30)
        label.backgroundColor = .green
        self.view.addSubview(label)
        
        // Do any additional setup after loading the view.
    }

}
//extensions
typealias StylingMethods = UILabel
extension StylingMethods {
    func setContent() {
    let string = self.text?.capitalized
    self.text = string
    }
}
//inheritance

class Demolabel: UILabel {
//    func setContent() {
//        let string = self.text?.capitalized
//        self.text = string
//    }
}

//
//  Cities+CoreDataClass.swift
//  
//
//  Created by AMBIN02948 on 07/06/22.
//
//

import Foundation
import CoreData

@objc(Cities)
public class Cities: NSManagedObject {

}

//
//  Cities+CoreDataProperties.swift
//  
//
//  Created by AMBIN02948 on 07/06/22.
//
//

import Foundation
import CoreData


extension Cities {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Cities> {
        return NSFetchRequest<Cities>(entityName: "Cities")
    }

    @NSManaged public var city: String?
    @NSManaged public var country: String?

}

//
//  NameofCities+CoreDataClass.swift
//  cities and images
//
//  Created by AMBIN03095 on 20/05/22.
//
//

import Foundation
import CoreData


public class NameofCities: NSManagedObject {

}

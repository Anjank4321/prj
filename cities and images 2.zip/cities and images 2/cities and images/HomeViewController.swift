//
//  HomeViewController.swift
//  cities and images
//
//  Created by AMBIN02948 on 20/05/22.
//

import UIKit
import WebKit
import SafariServices
class HomeViewController: UIViewController, WKNavigationDelegate,WKUIDelegate {
    var selectCity :String?
   
   
  
    @IBOutlet weak var webview: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
     
        guard let url = URL(string:"https://www.gmail.com/") else {return}
        let request = URLRequest(url: url)
                webview.load(request)
        webview.navigationDelegate = self
        webview.uiDelegate = self
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.navigationType == WKNavigationType.linkActivated {
            if let url1 = URL(string:"https://accounts.google.com/signup/v2/webcreateaccount?service=mail&continue=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F&dsh=S856150824%3A1654061735387393&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp"){
             let safariVC = SFSafariViewController(url: url1)
             present(safariVC,animated: true,completion: nil)
            }

               decisionHandler(WKNavigationActionPolicy.cancel)
               return
               
           }
        decisionHandler(WKNavigationActionPolicy.allow)
}
}

//
//  ViewController.swift
//  cities and images
//
//  Created by AMBIN02948 on 20/05/22.
//

import UIKit
import Alamofire
import CoreData
import Security
class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var dataofcities = [Cities]()
    var items:[Data1] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getitems{
        
            data1 in
            //self.items = jsonData.data
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }
        
        tableView.dataSource = self
        tableView.delegate = self
        
    }
    
  /* func getItems(comp: @escaping ([Data1]) -> ()){
        let url = URL(string: "https://countriesnow.space/api/v0.1/countries/population/cities")
        URLSession.shared.dataTask(with: url!) {
            data, reaponse, error in
            if error != nil {
                print(error?.localizedDescription)
                return
            }
            do{
                let result = try JSONDecoder().decode(cities.self, from: data!)
                //print(result)
                comp(result.data)
            }catch{
                
            }
        
        }.resume()
    
    }*/
    func getitems(comp: @escaping ([Data1]) -> ())
    {
            let url = "https://countriesnow.space/api/v0.1/countries/population/cities"
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
                        .responseJSON { response in
                            debugPrint(response)
                            if let data = response.result.value{
                                if  (data as? cities) != nil{
                                    //print("data_2: \(data)")
                                    if let jsonData = data as? cities{
//                                        let cityName = jsonData["msg"] as! String
                                       print(data)
                                        self.items = jsonData.data1
                                        
                                        let newItem = Cities(context.context)
                                        newItem.c
                                    }
                                }
                            }
                        }
//                  DispatchQueue.main.async {
//                          self.tableView.reloadData()
//                   }
        }
}

extension ViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row].country
        cell.detailTextLabel?.text = items[indexPath.row].city
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectcity = self.items[indexPath.row].city
        self.performSegue(withIdentifier: "navigatetoDetail", sender: selectcity)

   }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationController = segue.destination as? HomeViewController,let selectcity = sender as? String {
            destinationController.selectCity = selectcity
        }
    }
}

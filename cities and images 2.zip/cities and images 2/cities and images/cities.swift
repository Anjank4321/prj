//
//  cities.swift
//  cities and images
//
//  Created by AMBIN03095 on 20/05/22.
//

import Foundation
struct cities:Codable {
    var data1 :[Data1]
}
struct Data1:Codable{
    var city:String
    var country:String
}

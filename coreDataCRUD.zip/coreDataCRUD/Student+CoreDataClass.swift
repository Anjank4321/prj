//
//  Student+CoreDataClass.swift
//  coreDataCRUD
//
//  Created by AMBIN03085 on 04/02/22.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}

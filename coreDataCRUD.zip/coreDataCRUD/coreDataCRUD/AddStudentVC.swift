//
//  AddStudentVC.swift
//  coreDataCRUD
//
//  Created by AMBIN03085 on 04/02/22.
//

import UIKit

class AddStudentVC: UIViewController {

    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtstd: UITextField!
    @IBOutlet var txtschool: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func onClickAdd(_ sender: Any) {
        if let name = txtname.text , let std = txtstd.text , let school = txtschool.text  {
            let newStudent = Student(context: DBManager.share.context)
            newStudent.name = name
            newStudent.school = school
            newStudent.std = std
            DBManager.share.saveContext()
            
        }
    }
    

}

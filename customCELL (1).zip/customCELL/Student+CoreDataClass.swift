//
//  Student+CoreDataClass.swift
//  customCELL
//
//  Created by AMBIN03085 on 10/02/22.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}

//
//  HomeViewController.swift
//  customCELL
//
//  Created by AMBIN03085 on 10/02/22.
//

import UIKit
import CoreData

class HomeViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var school: UITextField!
    @IBOutlet weak var std: UITextField!
    var data = [Student]()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonclick(_ sender: Any) {
        
        
        if let name = name.text, let school = school.text,let std = std.text{
            let newstudent = Student(context: context)
            newstudent.name = name
            newstudent.school = school
            newstudent.std = std
            self.data.append(newstudent)
            do {
                try context.save()
            }catch {
                print("error")
            }
            navigationController?.popViewController(animated: true)
            
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

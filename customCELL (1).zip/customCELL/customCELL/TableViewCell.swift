//
//  TableViewCell.swift
//  customCELL
//
//  Created by AMBIN03085 on 10/02/22.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var Sname: UILabel!
    @IBOutlet weak var SSname: UILabel!
    @IBOutlet weak var School: UILabel!
    @IBOutlet weak var SchoolName: UILabel!
    @IBOutlet weak var Std: UILabel!
    @IBOutlet weak var StdName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

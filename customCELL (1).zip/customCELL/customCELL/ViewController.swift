//
//  ViewController.swift
//  customCELL
//
//  Created by AMBIN03085 on 10/02/22.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? TableViewCell
        let dataarray = self.data[indexPath.row]
        cell?.SSname.text = dataarray.name
        cell?.SchoolName.text = dataarray.school
        cell?.StdName.text = dataarray.std
        return cell!
        
    }
    
    
    
    @IBOutlet weak var tableview: UITableView!
    var  data = [Student]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.tableview.dataSource = self
        getdetails()
        title = "training"
        
    }
    func getdetails (){
        let request : NSFetchRequest<Student> = Student.fetchRequest()
        do{
            data = try context.fetch(request)
            
        }
        catch {
            print("error")
            
        }
        tableview.reloadData()
    }
}

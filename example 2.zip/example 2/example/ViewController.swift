//
//  ViewController.swift
//  example
//
//  Created by AMBIN03095 on 18/01/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtemployee: UITextField!
    @IBOutlet weak var txterror: UILabel!
    
    @IBOutlet weak var txtpassword: UITextField!
    override func viewDidLoad() {
       super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func txtbutton(_ sender: Any) {
        if let username = self.txtemployee?.text,let password = self.txtpassword?.text{
            if username.isEmpty || password.isEmpty{
                self.txterror.text = "username or password field is empty!"
            }else{
                 self.performSegue(withIdentifier: "returntohome", sender: self)
               self.txterror.text = "login successful!!"
            }
            
        }
    }
     
     override func prepare(for segue: UIStoryboardSegue,sender : Any?){
          if let destinationviewcontroller = segue.destination as? homeviewcontroller,let username = txtemployee.text as? String{
               destinationviewcontroller.employeeid = username
         }
    }
    
    
}


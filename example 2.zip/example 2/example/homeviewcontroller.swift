//
//  homeviewcontroller.swift
//  example
//
//  Created by AMBIN03095 on 19/01/22.
//

import UIKit

class homeviewcontroller: UIViewController {
        var employeeid:String?
    @IBOutlet weak var labeluicontroller: UILabel!
    
        override func viewDidLoad() {
           super.viewDidLoad()
            if self.employeeid != nil {
                self.labeluicontroller?.text = "welcome" + " " + "\(employeeid)"
            }
            
           // performSegue(withIdentifier: "v", sender: Any?))
        }
    }
    

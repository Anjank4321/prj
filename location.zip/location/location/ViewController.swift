//
//  ViewController.swift
//  location
//

//  Created by AMBIN03095 on 03/02/22.
//

import UIKit
import CoreLocation
class ViewController: UIViewController, CLLocationManagerDelegate {
      let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func GetLocation(_ sender: Any) {
        print("getlocaion")
        let status = CLLocationManager.authorizationStatus()
        
        
        switch status {
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
            print("not determines")
        case .denied, .restricted:
            print("denied")
            let alert = UIAlertController(title: "title", message: "location Auth", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
            return
        case .authorizedAlways, .authorizedWhenInUse:
            break
        default:
            print("Default status")
        }
        locationManager.delegate = self
        locationManager.startUpdatingLocation()
    }
    //Delegate methods
    //Error handling
    func locationManager(_ manager: CLLocationManager, didFailWithError: Error) {
        // temporary
        print("Error Scenario")
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // i am going to get the updating the current location
        if let currentLocation = locations.last {
            print("current location\(currentLocation)");
        }
    }
    
}


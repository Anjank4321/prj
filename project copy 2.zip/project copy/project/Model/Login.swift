//
//  Login.swift
//  project
//
//  Created by AMBIN03095 on 17/02/22.
//

import Foundation
struct weatherData:Codable {
    var weather:[Weather]
    var main: temperature
    var name : String
}
struct Weather:Codable {
    var id: Int
    var main:String
    var icon: String
}
struct temperature:Codable {
    var temp : Double
}

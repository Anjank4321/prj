//
//  ClimateOfCities+CoreDataClass.swift
//  project
//
//  Created by AMBIN03095 on 24/02/22.
//
//

import Foundation
import CoreData

@objc(ClimateOfCities)
public class ClimateOfCities: NSManagedObject {

}

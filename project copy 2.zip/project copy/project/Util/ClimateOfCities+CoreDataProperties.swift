//
//  ClimateOfCities+CoreDataProperties.swift
//  project
//
//  Created by AMBIN03095 on 24/02/22.
//
//

import Foundation
import CoreData


extension ClimateOfCities {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ClimateOfCities> {
        return NSFetchRequest<ClimateOfCities>(entityName: "ClimateOfCities")
    }

    @NSManaged public var cityName: String?
    @NSManaged public var temperature: Double
    @NSManaged public var main: String?

}

extension ClimateOfCities : Identifiable {

}

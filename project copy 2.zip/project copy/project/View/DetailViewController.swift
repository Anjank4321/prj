//
//  DetailViewController.swift
//  project
//
//  Created by AMBIN03095 on 18/02/22.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var searchCity: UITextField!
    @IBOutlet weak var tableview: UITableView!
    var weatherModel = WeatherModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func search(_ sender: Any) {
        var city = self.searchCity.text
        performSegue(withIdentifier: "navigateToHome", sender: city)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? HomeViewController, let city = sender as? String {
            destination.city = city
        }
    }
}

//
//  HomeViewController.swift
//  project
//
//  Created by AMBIN03095 on 21/02/22.
//

import UIKit
import CoreData

class HomeViewController: UIViewController {
    @IBOutlet weak var weatherLabel: UILabel!
    @IBOutlet weak var weatherImg: UIImageView!
    var weatherModel = WeatherModel()
    var items: [Weather] = []
    var city:String!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var dataofcities = [ClimateOfCities]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getItems()
        title = "\(city!)"
        // Do any additional setup after loading the view.
    }
    func getallitems(){
        do{
            dataofcities = try context.fetch(ClimateOfCities.fetchRequest())
            DispatchQueue.main.async {
            }
        }
        catch {
            
        }
    }
    func createitems(temperature: Double,main: String,cityName:String){
        let newitem = ClimateOfCities(context: context)
        newitem.temperature = temperature
        newitem.main = main
        newitem.cityName = cityName
        do{
            try context.save()
            print("successfully stored")
            getallitems()
            
        }
        catch {
            
        }
    }
    func getItems() {
        var defaultSession = URLSession(configuration: URLSessionConfiguration.default)
        var dataTask: URLSessionDataTask?
        print(city!)
        var url = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(city!)&appid=c0b1feef8919691dd37c4779eef5511a&units=imperial")
        
        var session = URLSession.shared
        var urlRequest = URLRequest(url: url!)
        urlRequest.httpMethod = "Post"
        dataTask = defaultSession.dataTask(with: urlRequest,completionHandler: { data, error, tempData in
            
            if let tempData = data {
                if let weatherInfo = try? JSONDecoder().decode(weatherData.self, from: tempData) {
                    DispatchQueue.main.async {
                        
                        self.items = weatherInfo.weather
                        self.createitems(temperature:weatherInfo.main.temp , main: weatherInfo.weather[0].main, cityName: weatherInfo.name )
                        //                            print( weatherInfo.main)]
                        print(self.items[0])
                        var img = weatherInfo.weather[0].icon
                        self.weatherImg.load(urlString: "https://openweathermap.org/img/wn/\(img)@2x.png")
                        self.weatherLabel.text = String("\(weatherInfo.main.temp) F")
                    }}
                
            }
            
        })
        dataTask?.resume()
    }
    
    
    
}
extension UIImageView {
    func load(urlString: String) {
        guard let url = URL(string: urlString)else {
            return
        }
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
                
            }
            
        }
    }
}




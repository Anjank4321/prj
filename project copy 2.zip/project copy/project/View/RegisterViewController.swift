//
//  HomeViewController.swift
//  project
//
//  Created by AMBIN03095 on 17/02/22.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var ConfirmPasswordError: UILabel!
    @IBOutlet weak var verifyPassword: UITextField!
    @IBOutlet weak var responseLbl: UILabel!
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var phnTxt: UITextField!
    @IBOutlet weak var userNameTxt: UITextField!
    @IBOutlet weak var EmailorUsernameError: UILabel!
    @IBOutlet weak var PasswordError: UILabel!
    var weatherModel = WeatherModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        userNameTxt.autocorrectionType = .no
        emailTxt.autocorrectionType = .no
        // Do any additional setup after loading the view.
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    
    @IBAction func signupBtn(_ sender: Any) {
        guard let username = userNameTxt.text,!username.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("Username field is empty") }
        guard let password = passwordTxt.text,!password.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("Password field is empty") }
        guard let phoneNumber = phnTxt.text,!phoneNumber.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("phone number field is empty") }
        guard let email = emailTxt.text,!email.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return
            print("email field is empty") }
        guard let vPassword = verifyPassword.text,!vPassword.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("Username field is empty") }
        if email.isValidEmail == true {
            self.EmailorUsernameError.text = ""
            if password == vPassword {
                self.ConfirmPasswordError.text = ""
        // Set attributes
        let attributes: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: username,
            kSecValueData as String: password.data(using: .utf8)!,
        ]
        // Add user
        if SecItemAdd(attributes as CFDictionary, nil) == noErr {
            
            responseLbl.text = "User saved successfully in the keychain"
                
        } else {
            responseLbl.text = "Something went wrong trying to save the user in the keychain"
            print("Success")
        }
            }else {
                ConfirmPasswordError.text = "password does not match"
            }
        }else{
            self.EmailorUsernameError.text = "Please enter the vailed email"
        }
        responseLbl.isHidden = false
        dismissKeyboard()
        }

}
extension String {
            var isValidEmail:Bool{
              let emailEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
              let emailTest = NSPredicate(format: "SELF MATCHES %@", emailEx)
            return emailTest.evaluate(with: self)
            }
}


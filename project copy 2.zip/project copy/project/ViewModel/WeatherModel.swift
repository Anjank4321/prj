//
//  weatherModelController.swift
//  project
//
//  Created by AMBIN03095 on 25/02/22.
//

import Foundation
class WeatherModel {
    
}

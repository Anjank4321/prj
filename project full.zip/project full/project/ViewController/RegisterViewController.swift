//
//  HomeViewController.swift
//  project
//
//  Created by AMBIN03095 on 17/02/22.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var verifyPassword: UITextField!
    @IBOutlet weak var responseLbl: UILabel!
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var phnTxt: UITextField!
    @IBOutlet weak var userNameTxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        userNameTxt.autocorrectionType = .no
        emailTxt.autocorrectionType = .no
        // Do any additional setup after loading the view.
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    
    @IBAction func signupBtn(_ sender: Any) {
        guard let username = userNameTxt.text,!username.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("Username field is empty") }
        guard let password = passwordTxt.text,!password.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("Password field is empty") }
        guard let phoneNumber = phnTxt.text,!phoneNumber.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("phone number field is empty") }
        guard let email = emailTxt.text,!email.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return
            print("email field is empty") }
        guard let vPassword = verifyPassword.text,!vPassword.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("Username field is empty") }

        // Set attributes
        let attributes: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: username,
            kSecAttrAccount as String: email,
            kSecValueData as String: password.data(using: .utf8)!,
        ]
        // Add user
        if SecItemAdd(attributes as CFDictionary, nil) == noErr {

            responseLbl.text = "User saved successfully in the keychain"
        } else {
            responseLbl.text = "Something went wrong trying to save the user in the keychain"
        }
        responseLbl.isHidden = false
        dismissKeyboard()
    }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */



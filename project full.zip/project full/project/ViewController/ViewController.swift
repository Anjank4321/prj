//
//  ViewController.swift
//  project
//
//  Created by AMBIN03095 on 17/02/22.
//

import UIKit
import Security

class ViewController: UIViewController {
    @IBOutlet weak var loginPassword:UITextField!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var loginEmail:UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loginEmail.autocorrectionType = .no
        resultLbl.isHidden = true
        let tapGes = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGes)
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
        
    }

    @IBAction func loginTap(_ sender: Any) {
        guard let loginMail = loginEmail.text,!loginMail.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("Email field is empty") }
        guard let loginKey = loginPassword.text,!loginKey.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return print("Password field is empty") }

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: loginMail,
           // kSecAttrKeyType as String: loginKey,
            kSecMatchLimit as String: kSecMatchLimitOne,
            kSecReturnAttributes as String: true,
            kSecReturnData as String: true,
        ]
        var item: CFTypeRef?

        // Check if user exists in the keychain
        if SecItemCopyMatching(query as CFDictionary, &item) == noErr {
            resultLbl.isHidden = true
            // Extract result
            if let existingItem = item as? [String: Any],
               let username = existingItem[kSecAttrAccount as String] as? String,
               let loginKey1 = existingItem[kSecValueData as String] as? Data,
               let password1 = String(data: loginKey1, encoding: .utf8) {
            // let str = String(decoding: loginKey, as: UTF8.self)
                resultLbl.isHidden = false
                 if username == loginMail && password1 == loginKey {
                resultLbl.text =  "Login Successfully"
                }else {
                    resultLbl.isHidden = false
                    resultLbl.text = "Something went wrong trying to find the Email and password "
                    
                }
                dismissKeyboard()
            }
        }else {
        resultLbl.isHidden = false
        resultLbl.text = "Username and password does not exist  "

    }
}
        
    @IBAction func Register(_ sender: Any) {
        if let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RegisterViewController") as? RegisterViewController {
        navigationController?.pushViewController(nextVc, animated: true)
       }
    }
}

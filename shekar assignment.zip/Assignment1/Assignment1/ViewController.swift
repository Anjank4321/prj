//
//  ViewController.swift
//  Assignment1
//
//  Created by AMBIN02948 on 21/06/22.
//

import UIKit
import Alamofire
import CoreData
import Security

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    //    var city:[[String:Any]] = []
   // var items:[Data1] = []
    var newitem = [Datamodel]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    //  let object = Datamodel(context:context)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       getitems()
      fetch()
        
        tableView.dataSource = self
        tableView.delegate = self
        
    }
   
    func getitems()
    {
        let url = "https://countriesnow.space/api/v0.1/countries/population/cities"
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
            .responseJSON { response in
                debugPrint(response)
                if let data = response.result.value{
                    if  (data as? [String : AnyObject]) != nil{
                        if let jsonData = data as? [String : AnyObject]{
                            if let cityData = jsonData["data"] as? Array<Any>{
                                var cityNames:[Any] = []
                                var countryNames:[Any] = []
                                for cityDict in cityData{
                                    if let city = cityDict as? [String:Any]{
                                        if let cityName = city["city"] as? String, let countryName = city["country"] as? String{
                                            cityNames.append(cityName)
                                            
                                            countryNames.append(countryName)
                                        }
                                    }
                                 
                                }
                              // print(cityNames)
                               // print(countryNames)
                              let  length = cityNames.count
                                
                                for index in (0...length-1){
                                    self.storage(city:cityNames[index] as! String  , country:countryNames[index] as! String)
                                
                                
                                }
                            }
                        }
                    }
                }
            }
    }
    func storage(city:String,country:String){
        let object = Datamodel(context:context)
        object.city = city
        object.country = country
       // print(object)
        save()
        fetch()
        
    }
    func save(){
        do{
            try context.save()
           // print("Details saed successfully")
        }
        catch{
            print("Error")
        }
    }
    func fetch(){
        do{
            newitem = try context.fetch(Datamodel.fetchRequest())
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
           // print("details fetched successfully")
        }
        catch{
            print("Error")
        }
    }
    
}

extension ViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newitem.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = newitem[indexPath.row].country
        cell.detailTextLabel?.text = newitem[indexPath.row].city
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectcity = self.newitem[indexPath.row].city
//        self.performSegue(withIdentifier: "navigatetoDetail", sender: selectcity
        if let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController {
       
        navigationController?.pushViewController(nextVc, animated: true)
          print("success")
    }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if let destinationController = segue.destination as? HomeViewController,let selectcity = sender as? String {
//            destinationController.selectCity = selectcity
//        }
//    }
}
          }

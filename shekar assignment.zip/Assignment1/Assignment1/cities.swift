//
//  cities.swift
//  Assignment1
//
//  Created by AMBIN02948 on 21/06/22.
//

import Foundation
struct cities:Codable {
    var data1 :[Data1]
}
struct Data1:Codable{
    var city:String
   var country:String
}

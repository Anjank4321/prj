//
//  Datamodel+CoreDataClass.swift
//  Assignment1
//
//  Created by AMBIN02948 on 21/06/22.
//
//

import Foundation
import CoreData

@objc(Datamodel)
public class Datamodel: NSManagedObject {

}

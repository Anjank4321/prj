//
//  Datamodel+CoreDataProperties.swift
//  Assignment1
//
//  Created by AMBIN02948 on 21/06/22.
//
//

import Foundation
import CoreData


extension Datamodel {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Datamodel> {
        return NSFetchRequest<Datamodel>(entityName: "Datamodel")
    }

    @NSManaged public var city: String?
    @NSManaged public var country: String?

}

extension Datamodel : Identifiable {

}

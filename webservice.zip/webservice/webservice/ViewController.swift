//
//  ViewController.swift
//  webservice
//
//  Created by AMBIN03095 on 26/01/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource {
   
    
    @IBOutlet weak var tableview: UITableView!
   // var items:[[String:Any]] = []
     var items : [Result] = []
        override func viewDidLoad() {
        super.viewDidLoad()
            self.getItems()
          self.tableview.dataSource = self
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell")
        let item = self.items[indexPath.row]
        cell?.textLabel?.text = item.trackName//item["trackName"] as? String
        return cell!
    }
    func getItems() {
        let defaultSession = URLSession(configuration: URLSessionConfiguration.default)
        var dataTask: URLSessionDataTask?
        let url = URL(string: "https://itunes.apple.com/search/media=music&entity=song&term=item")!
        let urlRequest = URLRequest(url: url)
        dataTask = defaultSession.dataTask(with: urlRequest,completionHandler: { data, response, error
        in
                if let tempData = data {
                   if let welcome = try? JSONDecoder().decode(Welcome.self, from: tempData) {
                        DispatchQueue.main.async {
                            self.items = welcome.results
                            self.tableview.reloadData()
                        }}
                   /* do {
                        if let jsonResponce = try JSONSerialization.jsonObject(with: tempData, options: [])
                            as? [String:Any] {
                            if let results = jsonResponce["results"] as? [[String:Any]] {
                                self.items = results
                                DispatchQueue.main.async {
                                    self.tableview.reloadData()
                                }
                            }
                           // print(jsonResponce)
                            
                    }
                    }catch {
                    }*/
                    
                }
        
                })
    dataTask?.resume()
  }


    }
        
                                           

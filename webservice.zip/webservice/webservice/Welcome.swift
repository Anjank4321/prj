//
//  Welcome.swift
//  webservice
//
//  Created by AMBIN03095 on 28/01/22.
//

import Foundation
struct Welcome : Codable {
    let resultCount: Int
    let results : [Result]
}
struct Result :Codable {
    let wrapperType : String
    let kind : String
    let artistName: String
    let collectionName,trackName,collectionCensoredName,trackCensoredName: String
    let artworkUrl30,artworkUrl60,artworkUrl100:String
    
}


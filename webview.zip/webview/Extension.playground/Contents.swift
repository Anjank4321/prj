import UIKit
//struct Size {
//    var width = 0.0, height = 0.0
//}
//struct Point {
//    var x = 0.0, y = 0.0
//}
//
//struct Rect {
//    var origin = Point()
//    var size = Size()
//}
//
//let rect = Rect(origin: Point(x: 0.0, y: 0.0), size: Size(width: 10.0, height: 10.0))
//
////Initializers
//extension Rect {
//    init(squreOrigin:Point,SquareSize:Size) {
//        self.init(origin: squreOrigin, size: SquareSize)
//    }
////    init(center:Point,size:Size) {
////        let originX = center.x - (size.width / 2)
////                let originY = center.y - (size.height / 2)
////                self.init(origin: Point(x: originX, y: originY), size: size)
////    }
//}

////Computed properties in extension
//extension Double {
//    var km: Double { return self * 1_000.0 }
//    var m: Double { return self }
//    var cm: Double { return self / 100.0 }
//    var mm: Double { return self / 1_000.0 }
//    var ft: Double { return self / 3.28084 }
//}
//let oneInch = 25.4.mm
//print("One inch is \(oneInch) meters")
//let threeFeet = 3.ft
//print("Three feet is \(threeFeet) meters")

//Mehtods
extension Int {
    func repetitions(task: () -> Void) {
        for _ in 0..<self {
            task()
        }
    }
    mutating func square() {
            self = self * self
    }
    subscript(digitIndex: Int) -> Int {
            var decimalBase = 1
            for _ in 0..<digitIndex {
                decimalBase *= 10
            }
            return (self / decimalBase) % 10
        }
}

12345678[3]

//var squareValue = 3
//squareValue.square()
//print(squareValue)

//print(123456789[3])
//var someInt = 3
//someInt.square()
//
3.repetitions {
    print("Hello!")
}

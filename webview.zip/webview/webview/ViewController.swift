//
//  ViewController.swift
//  webview
//
//  Created by M_AMBIN04868 on 17/02/22.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate {
    var webview:WKWebView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let wkWebView = WKWebView()
        wkWebView.navigationDelegate = self
        wkWebView.allowsBackForwardNavigationGestures = true
        self.webview = wkWebView
        view = webview
        self.loadHMTLString()
       // self.load("https://www.google.com")
    }
    //Mark: webview delegate methods
    //implement the decidePolicyFor method. This is the only part that takes any work: you need to pull out the host of the URL that was requested, run any checks you want to make sure it’s OK, then call the decisionHandler() closure with either .allow to allow the URL or .cancel to deny access.
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        
       /* if let host = navigationAction.request.url?.host {
            //print(#function, host)
            if host.contains("google.com") {
                decisionHandler(.allow)
                return
            }
        }
        decisionHandler(.cancel)*/
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
         // view.hideLoading()
        let js = "var myelement = document.getElementById(\"test\");myelement.innerHTML= \"New Text\";"
        self.webview?.evaluateJavaScript(js, completionHandler: { (id, error) in
            print(error)
        })
       

      }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
           print(error.localizedDescription)
       }
}

extension ViewController {
    
    func loadHMTLString() {
        guard let contentxURL:URL =
                Bundle.main.url(forResource:"sample", withExtension: "html")
        else{
            return
        }
        let contentX = (try? String(contentsOf: contentxURL)) ?? ""
        webview?.loadHTMLString(contentX, baseURL: Bundle.main.bundleURL)
    }
    
    func load(_ urlString: String) {
        
        if let url = URL(string: urlString) {
            let request = URLRequest(url: url)
            webview?.load(request)
        }
    }
}

